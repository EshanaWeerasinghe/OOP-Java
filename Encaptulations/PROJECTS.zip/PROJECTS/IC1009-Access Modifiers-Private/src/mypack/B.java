package mypack;
import pack.*;  

//Outside the pakage:Add Child class /Inheritance 
public class B extends A{
//The A class of pack package is public.so can be accessed from outside the package.
//msg method of this package is declared as protected, 
//so it can be accessed from outside the class only through inheritance.

    public static void main(String[] args) {
    B obj = new B();  
    obj.msg();
    }

}
