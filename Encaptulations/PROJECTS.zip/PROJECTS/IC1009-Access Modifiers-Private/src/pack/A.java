package pack;

/**
 *
 * @author Eshana
 */
public class A {
   protected void msg(){System.out.println("Hello");}  
}
