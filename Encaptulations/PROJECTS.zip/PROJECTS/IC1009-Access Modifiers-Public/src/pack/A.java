package pack;
/**
 *
 * @author Eshana
 */
public class A {
    public void msg(){System.out.println("Hello");}  
}
