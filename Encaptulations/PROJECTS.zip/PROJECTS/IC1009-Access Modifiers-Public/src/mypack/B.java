  
package mypack;  
import pack.*;  
  
class B{  
    
    
  public static void main(String args[]){ 
   //Class A object accesss indirect   
   A obj = new A();  
   obj.msg();  
  }  
} 