package Method1;
/**
 *
 * @author Eshana
 */
public class Main {
//To call a method in Java, write the method's name followed by two parentheses () and a semicolon;
//Inside main, call the myMethod() method:
//myMethod() is used to print a text (the action), when it is called:

    static void myMethod() {
        System.out.println("Hello World!");
    }

  
    public static void main(String[] args) {
        //A method can also be called multiple times:
        myMethod();
      
    }
    
}
