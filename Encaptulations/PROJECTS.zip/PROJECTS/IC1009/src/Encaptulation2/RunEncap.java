package Encaptulation2;

/**
 *
 * @author Eshana
 */
public class RunEncap {

    public static void main(String[] args) {
        EncapTest encap = new EncapTest();
        encap.setName("Kasun");
        encap.setIdNum("901531223v");
        encap.setAge(27);
        System.out.print("Name:" +encap.getName()+ "Age:" +encap.getAge()+ "ID:" +encap.getAge());
        
    }
    
}
