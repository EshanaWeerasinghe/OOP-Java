package Encaptulation2;

/**
 *
 * @author Eshana
 */
public class EncapTest {

    private String name;
    private String idNum;
    private int age;

    public String getName() {
        return name;
    }

    public String getIdNum() {
        return idNum;
    }

    public int getAge() {
        return age;
    }

    public void setName(String Newname) {
        this.name = Newname;
    }

    public void setIdNum(String newId) {
        this.idNum = newId;
    }

    public void setAge(int Newage) {
        this.age = Newage;
    }

}
