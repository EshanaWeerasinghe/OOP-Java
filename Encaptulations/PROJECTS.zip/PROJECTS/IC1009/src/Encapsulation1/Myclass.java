package Encapsulation1;
/**
 *
 * @author Eshana
 */
public class Myclass {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Student obj1 = new Student();
       obj1.setName("Kasun");
       System.out.println(obj1.getName());
    }
    
}
