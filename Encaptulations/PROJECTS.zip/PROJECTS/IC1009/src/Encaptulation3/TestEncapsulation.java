package Encaptulation3;
/**
 *
 * @author Eshana
 */
public class TestEncapsulation {

    public static void main(String[] args) {
    //creating instance of Account class  
    Account acc=new Account();  
    //setting values through setter methods  
    acc.setAcc_no(7560504000L);  
    acc.setName("Kasun");  
    acc.setEmail("kasun@gmail.com");  
    acc.setAmount(100000);  
    //getting values through getter methods  
    System.out.println(acc.getAcc_no()+" "+acc.getName()+" "+acc.getEmail()+" "+acc.getAmount());  
    }
    
}
