package pakage1;
/**
 *
 * @author Eshana
 */
public class Main {
 int x;  // Create a class attribute

  // Create a class constructor for the Main class
  public Main() {
    x = 5;  // Set the initial value for the class attribute x
  }
}
