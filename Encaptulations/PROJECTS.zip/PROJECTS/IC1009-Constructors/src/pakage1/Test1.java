package pakage1;
/**
 *
 * @author Eshana
 */
public class Test1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Main myObj = new Main(); // Create an object of class Main (This will call the constructor)
    System.out.println(myObj.x); // Print the value of x
    }
    
}
