package pakage3;
/**
 *
 * @author Eshana
 */
public class Main {
  int modelYear;
  String modelName;

  public Main(int year, String name) {
    modelYear = year;
    modelName = name;
}
}
