package pakage3;

/**
 *
 * @author Eshana
 */
public class Test3 {
    
    public static void main(String[] args) {
    //You can have as many parameters as you want:
    Main myCar = new Main(1969, "Mustang");
    System.out.println(myCar.modelYear + " " + myCar.modelName);
    }
    
}
