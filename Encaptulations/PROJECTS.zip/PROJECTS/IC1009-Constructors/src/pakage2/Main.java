package pakage2;

/**
 *
 * @author Eshana
 */
public class Main {

    int x;

//adds an int y parameter to the constructor
//Inside the constructor we set x to y (x=y)
    public Main(int y) {
        x = y;
    }
}
