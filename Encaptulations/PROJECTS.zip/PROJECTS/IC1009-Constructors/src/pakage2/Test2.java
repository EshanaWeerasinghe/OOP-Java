package pakage2;

/**
 *
 * @author Eshana
 */
public class Test2 {

    public static void main(String[] args) {
        //pass a parameter to the constructor (5), which will set the value of x to 5:
        Main myObj = new Main(5);
        System.out.println(myObj.x);
    }

}
