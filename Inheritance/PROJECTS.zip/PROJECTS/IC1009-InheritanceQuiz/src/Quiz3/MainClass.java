class A
{
    static
    {
        System.out.println("University Of Colombo");
    }
}
 
class B extends A
{
    static
    {
        System.out.println("Faculty Of Technology");
    }
}
 
class C extends B
{
    static
    {
        System.out.println("Department Of ICT");
    }
}
 
public class MainClass
{
    public static void main(String[] args)
    {
        C c = new C();
    }
}