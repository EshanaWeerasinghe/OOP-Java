package Quiz2;

class A
{
    {
        System.out.println(10);
    }
}
 
class B extends A
{
    {
        System.out.println(9);
    }
}
 
class C extends B
{
    {
        System.out.println(1);
    }
}
public class MainClass {

    public static void main(String[] args) {
        C c = new C();
    }
    
}
