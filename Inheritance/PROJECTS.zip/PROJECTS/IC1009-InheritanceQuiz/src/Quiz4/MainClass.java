package Quiz4;
class X
{
    static void staticMethod()
    {
        System.out.println("IC 1009");
    }
}
 
class Y extends X
{
    static void staticMethod()
    {
        System.out.println("Inheritance");
    }
}
 
public class MainClass
{
    public static void main(String[] args)
    {
        Y.staticMethod();
    }
}