package multilevelInheritance;

/**
 *
 * @author Eshana
 */
public class BabyDog extends Dog{
    void weep(){
        System.out.println("Weeping..");
    }
    
}
