package ic1009.inheritance;

class A
{
    int i = 200;
}
 
class B extends A
{
    int i = 20;
}
public class IC1009Inheritance {

    public static void main(String[] args) {
        A a = new B();
 
        System.out.println(a.i);
    }
    
}
