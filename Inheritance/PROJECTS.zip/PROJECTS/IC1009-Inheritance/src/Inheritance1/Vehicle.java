package Inheritance1;
/**
 *
 * @author Eshana
 */
public class Vehicle { 
//Vihical attribute set to a protected access modifier 
//If it was set to private, the Car class would not be able to access it.    
protected String brand = "Ford"; // Vehicle attribute
public void honk() {// Vehicle method
System.out.println("Tuut, tuut!"); 
    }
}
