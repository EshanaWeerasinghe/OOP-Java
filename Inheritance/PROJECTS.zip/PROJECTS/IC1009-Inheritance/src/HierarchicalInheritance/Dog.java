package HierarchicalInheritance;

/**
 *
 * @author Eshana
 */
public class Dog extends Animal {
    void bark(){
        System.out.println("barking..");
    }
    
}
