package HierarchicalInheritance;

/**
 *
 * @author Eshana
 */
public class TestInheritance3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     Cat c = new Cat();
     c.meow();
     c.eat();
    }
    
}
