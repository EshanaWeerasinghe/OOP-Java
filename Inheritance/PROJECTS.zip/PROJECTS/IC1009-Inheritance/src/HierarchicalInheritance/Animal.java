package HierarchicalInheritance;

/**
 *
 * @author Eshana
 */
public class Animal {
    void eat(){
        System.out.println("eating..");
    }
    
}
