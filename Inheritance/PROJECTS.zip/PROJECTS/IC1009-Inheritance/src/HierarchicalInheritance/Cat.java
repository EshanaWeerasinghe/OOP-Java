package HierarchicalInheritance;

/**
 *
 * @author Eshana
 */
public class Cat extends Animal {
    void meow(){
        System.out.println("meow...");
    }
    
}
