package SingleInheritance;

/**
 *
 * @author Eshana
 */
public class TestInheritance {

    public static void main(String[] args) {
        Dog d = new Dog();
        d.bark();
        d.eat();
    }
    
}
