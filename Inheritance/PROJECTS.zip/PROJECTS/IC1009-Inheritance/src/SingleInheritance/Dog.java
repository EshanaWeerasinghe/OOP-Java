package SingleInheritance;
/**
 *
 * @author Eshana
 */

//Dog class inherits the Animal class
//So there is the single Inheritance
public class Dog extends Animal{
    
    void bark(){
        System.out.println("Barking..");
    }
    
}
