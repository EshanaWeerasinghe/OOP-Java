package Example;

/**
 *
 * @author Eshana
 */
public class Student {
    
    String role ="Student";
    String faculty ="FOT";
    
    void does(){
        System.out.println("Study");
    }
    
}
