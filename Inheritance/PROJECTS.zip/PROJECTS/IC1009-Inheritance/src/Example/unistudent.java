package Example;

/**
 *
 * @author Eshana
 */
public class unistudent extends Student {

    String course ="IC 1009";

    public static void main(String[] args) {
     unistudent obj = new unistudent();
     System.out.println(obj.faculty);
     System.out.println(obj.course);   
     System.out.println(obj.role);
     obj.does();
    }
    
}
