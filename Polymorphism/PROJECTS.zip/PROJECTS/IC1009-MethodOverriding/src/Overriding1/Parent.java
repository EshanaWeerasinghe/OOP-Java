package Overriding1;

/**
 *
 * @author Eshana
 */
public class Parent {
    int a=50;
    public void display()
    {
    System.out.println("Display method of Parent class");
    }
}
