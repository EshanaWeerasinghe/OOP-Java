package Overriding1;

/**
 *
 * @author Eshana
 */
public class Child extends Parent {
    int b=100;
    public void display()
    {
    System.out.println("Display method of Child class");
    }
}
