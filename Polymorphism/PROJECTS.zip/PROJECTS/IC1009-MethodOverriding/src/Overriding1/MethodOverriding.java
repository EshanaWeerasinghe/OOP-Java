package Overriding1;

/**
 *
 * @author Eshana
 */
//display method in the subclass as defined in the parent class but it has some specific implementation. 
public class MethodOverriding {

    public static void main(String[] args) {
     Child d=new Child();
     d.display();
    } 
}
