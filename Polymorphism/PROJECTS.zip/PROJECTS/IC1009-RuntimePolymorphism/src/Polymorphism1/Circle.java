package Polymorphism1;
/**
 *
 * @author Eshana
 */
public class Circle extends Shape {
  void draw(){
      System.out.println("drawing circle...");
  }   
}
