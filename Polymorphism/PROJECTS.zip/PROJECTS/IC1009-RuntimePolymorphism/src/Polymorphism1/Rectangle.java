package Polymorphism1;

/**
 *
 * @author Eshana
 */
public class Rectangle extends Shape{
    void draw(){
        System.out.println("drawing rectangle...");
    }     
}
