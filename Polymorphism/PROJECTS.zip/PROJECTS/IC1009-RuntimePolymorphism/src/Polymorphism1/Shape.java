package Polymorphism1;

/**
 *
 * @author Eshana
 */
public class Shape {
    void draw(){
        System.out.println("drawing...");
    }    

}
