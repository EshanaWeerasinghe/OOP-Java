package Polymorphism1;

/**
 *
 * @author Eshana
 */
public class Test {

    public static void main(String[] args) {
        //created object & implemented the multiple methods 
        Shape s;  
        s=new Rectangle();  
        s.draw();  
        s=new Circle();  
        s.draw();  
        s=new Triangle();  
        s.draw();
    }
    
}
