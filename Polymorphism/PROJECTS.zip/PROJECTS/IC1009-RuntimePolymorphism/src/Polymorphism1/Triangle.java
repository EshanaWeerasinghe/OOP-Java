package Polymorphism1;

/**
 *
 * @author Eshana
 */
public class Triangle extends Shape {
    void draw(){
        System.out.println("drawing triangle...");
    }  
}
