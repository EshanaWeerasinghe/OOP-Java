package Overloading4;

/**
 *
 * @author Eshana
 */
public class hello {
    
//Two overloaded methods that differs in data type.
    
    //first sum method receives two integer arguments 
    public void sum(int a, int b)
    {
    System.out.println(a+b);
    }
    

//second sum method receives two double arguments.
    public void sum(double a, double b)
    {
    System.out.println(a+b);
    }

    public static void main(String[] args) {
        
        hello h = new hello();
        h.sum(10,20);
        h.sum(10.20, 30.50);
        System.out.println("Hello Java");
    }
    
}
