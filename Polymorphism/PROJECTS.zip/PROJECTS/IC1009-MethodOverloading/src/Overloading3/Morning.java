package Overloading3;

/**
 *
 * @author Eshana
 */

// Two overloaded methods,
public class Morning {
    
 // first sum method performs addition of two numbers   
public void sum(int a, int b)
{
System.out.println(a+b);
}

// second sum method performs addition of three numbers
public void sum(int a,int b,int c)
{
System.out.println(a+b+c);
}
   
    public static void main(String[] args) {
        Morning h=new Morning();
        h.sum(10,20);
        h.sum(10,20,30);
        System.out.println("Hello Java");
    }
    
}
