package MultipleInheritance1;

/**
 *
 * @author Eshana
 */

//Interface only one specifier is Public
public interface Printable {
 void print();     
}
