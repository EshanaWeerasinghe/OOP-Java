package MultipleInheritance1;

/**
 *
 * @author Eshana
 */
public interface Showable {
 void show();    
}
