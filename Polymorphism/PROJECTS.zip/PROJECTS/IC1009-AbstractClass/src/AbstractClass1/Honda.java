package AbstractClass1;

/**
 *
 * @author Eshana
 */

//Creating a Child class which inherits Abstract class 
 class Honda extends Bike {
   void run(){
       System.out.println("running safely..");
   }  
}
