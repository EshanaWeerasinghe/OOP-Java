package AbstractClass1;

/**
 *
 * @author Eshana
 */
public class TestAbstraction {
//An abstract class can have a data member, 
//abstract method, method body (non-abstract method), constructor, and even main() method.
    public static void main(String[] args) {
          Bike obj = new Honda();  
          obj.run();  
          obj.changeGear();
    }
    
}
